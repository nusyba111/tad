{
    'name': "SRCS Inventory",

    'summary': """
        """,

    'description': """
    """,
    'version': '15.0',
    'author': "IATL International",
    'website': "http://www.iatl-sd.com",
    # 'category': 'Accounting/Common',
    'depends': ['srcs_purchase', 'stock'],
    'data': [
             
            'views/srcs_stock.xml',
           
            'views/product.xml',
            'Report/transfer.xml',
            'Report/header_footer.xml',

            
    ],
}